import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:google_fonts/google_fonts.dart';
import 'package:poolsensorsystem/chart.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.blue[700],
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        // primarySwatch: Colors.blue,
      ),
      home: const MyWidget(),
    );
  }
}

class MyWidget extends StatefulWidget {
  const MyWidget({Key? key}) : super(key: key);

  @override
  _MyWidgetState createState() => _MyWidgetState();
}

class _MyWidgetState extends State<MyWidget> {
  late double temperature = 0.0;

  Future<void> getData() async {
    final response = await http.get(Uri.parse(
        'https://api.openweathermap.org/data/2.5/weather?q=Berlin&appid=YOUR_API_KEY'));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      setState(() {
        temperature = data['main']['temp'] - 273.15;
        print("done");
      });
    } else {
      //show a snakcbar error
      
    }
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Title Pool',
          style: TextStyle(fontSize: 24),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: () {
              getData();
              print("relaod");
            },
            icon: Icon(Icons.receipt),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            DataCard(
              title: temperature.toStringAsFixed(1),
              subtitle: 'Temperatur',
              icon: Icons.device_thermostat,
              primary: Colors.blue,
              secondary: Colors.red,
              onPressed: () {
                print('Pressed');
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Page1()),
                );
              },
            ),
            DataCard(
              title: '25sds',
              subtitle: 'Temperasdsdtur',
              icon: Icons.device_thermostat,
              primary: Colors.blue,
              secondary: Colors.red,
              onPressed: () {
                print('Pressed');
              },
            ),
            DataCard(
              title: 'sdds5',
              subtitle: 'Tempersdsatur',
              icon: Icons.device_thermostat,
              primary: Colors.blue,
              secondary: Colors.red,
              onPressed: () {
                print('Pressed');
              },
            ),
            DataCard(
              title: '25',
              subtitle: 'Temperatur',
              icon: Icons.device_thermostat,
              primary: Colors.blue,
              secondary: Colors.red,
              onPressed: () {
                print('Pressed');
              },
            ),
          ],
        ),
      ),
    );
  }
}

class Page1 extends StatelessWidget {
  const Page1({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('test1'),
      ),
      body: Column(
        children: [
          LineChartSample2(),
        ],
      ),
    );
  }
}

class DataCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color primary;
  final Color secondary;
  final VoidCallback onPressed;

  const DataCard({
    Key? key,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.primary,
    required this.secondary,
    required this.onPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      child: Card(
        color: secondary,
        child: ListTile(
          trailing: Icon(
            icon,
            size: 100,
            color: primary,
          ),
          title: Padding(
            padding: EdgeInsets.fromLTRB(7, 50, 0, 0),
            child: Text(
              title,
              style: GoogleFonts.poppins(
                color: primary,
                fontSize: 60,
                fontWeight: FontWeight.bold,
                height: 1,
              ),
            ),
          ),
          subtitle: Padding(
            padding: EdgeInsets.fromLTRB(7, 0, 0, 15),
            child: Text(
              subtitle,
              style: GoogleFonts.poppins(
                fontSize: 18,
                color: primary,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
