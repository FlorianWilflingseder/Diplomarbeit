package com.example.poolsensorsystem

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
